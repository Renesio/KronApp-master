package com.xetelas.nova.Adapter;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.xetelas.nova.Fragments.Fragment_Buscar;
import com.xetelas.nova.Fragments.Fragment_Minhas;
import com.xetelas.nova.Fragments.Fragment_Oferecer;

public class MyFragmentPagerAdapter extends FragmentPagerAdapter {

    private String[] nTabTitle;

    public MyFragmentPagerAdapter(FragmentManager fm, String[] nTabTitle) {
        super(fm);
        this.nTabTitle = nTabTitle;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0:
                return new Fragment_Minhas();
            case 1:
                return new Fragment_Buscar();
            case 2:
                return new Fragment_Oferecer();
            default:
                return null;

        }
    }

    @Override
    public int getCount() {
        return this.nTabTitle.length;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return this.nTabTitle[position];
    }
}
